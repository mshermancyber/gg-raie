import { defineConfig, loadEnv } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), "");

  return {
    plugins: [react()],
    // Expose env vars to the client — Vite only exposes VITE_ prefixed by default
    // We use define to explicitly pass through our AI config vars
    define: {
      __LOCAL_AI_BASE_URL__: JSON.stringify(env.LOCAL_AI_BASE_URL),
      __LOCAL_AI_MODEL__: JSON.stringify(env.LOCAL_AI_MODEL),
      __FALLBACK_AI_BASE_URL__: JSON.stringify(env.FALLBACK_AI_BASE_URL),
      __FALLBACK_AI_MODEL__: JSON.stringify(env.FALLBACK_AI_MODEL),
      __FALLBACK_AI_API_KEY__: JSON.stringify(env.FALLBACK_AI_API_KEY),
      __AI_BACKEND__: JSON.stringify(env.AI_BACKEND || "local"),
    },
    server: {
      port: 5173,
    },
  };
});
