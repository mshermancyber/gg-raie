# AI Governance Risk Intelligence Platform

**2LoD AI/ML governance assessment tool for financial services — built for senior risk practitioners.**

A two-phase web application that combines structured model intake with agentic AI reasoning to produce a complete Second Line of Defense governance assessment packet.

---

## What It Does

### Phase 1 — Model Intake Assessment
Structured intake form covering: model identity, training data lineage, PII/PFI exposure, explainability methods, human oversight checkpoints, bias testing, drift monitoring, regulatory alignment (SR 11-7, ECOA, NIST AI RMF), and validation status. AI produces a risk tier, dimension-level ratings, 2LoD challenge questions, and recommended actions.

### Phase 2 — Agentic 2LoD Review
Paste any artifact (model card, architecture notes, control evidence, incident summary, policy text) and the AI agent reasons through it step by step — building an evidence trace, flagging control gaps, assigning severity, and producing a risk memo narrative. Reasoning steps are fully visible.

### Phase 3 — Risk Report & Export
Combined risk report with dimension heatmap, challenge questions, escalation determination, and downloadable assessment packet in formatted text.

---

## Tech Stack

- **Frontend:** React + Vite
- **AI Backend:** Local llama.cpp instance (OpenAI-compatible `/v1` endpoint) via `.env` config
- **Fallback:** Anthropic API (or any OpenAI-compatible endpoint)
- **Model-agnostic:** swap backends via a single `.env` variable

---

## Setup

```bash
# Install dependencies
npm install

# Copy env template and fill in your values
cp .env.example .env
# Edit .env with your llama.cpp endpoint and model name

# Start dev server
npm run dev
```

## Environment Variables

```
LOCAL_AI_BASE_URL=http://192.168.x.x:PORT/v1
LOCAL_AI_MODEL=your-model.gguf

FALLBACK_AI_BASE_URL=https://api.anthropic.com/v1
FALLBACK_AI_MODEL=claude-sonnet-4-20250514
FALLBACK_AI_API_KEY=your_key_here

AI_BACKEND=local   # or "fallback"
```

---

## Mock Scenario

A pre-loaded mock scenario ("Digital Lending Decisioning Model v2.3") ships with the app — a consumer credit scoring model with undocumented third-party data lineage, no post-retrain validation, limited explainability, and missing fairness monitoring. Designed to trigger multiple HIGH/ELEVATED governance flags to demonstrate the full assessment pipeline.

---

## Portfolio Context

Built to demonstrate 2LoD technology risk governance competencies including:
- SR 11-7 model risk management
- AI governance, ethical considerations, and explainability
- Agentic AI for automated risk investigation
- KPI/KRI production and senior stakeholder reporting
- ECOA/FCRA/NIST AI RMF regulatory alignment

**Author:** Mark Sherman · [github.com/mshermancyber](https://github.com/mshermancyber) · [linkedin.com/in/mshermancyber](https://linkedin.com/in/mshermancyber)
