import { useState, useRef } from "react";
import IntakeForm from "./components/IntakeForm.jsx";
import AgentReviewer from "./components/AgentReviewer.jsx";
import RiskReport from "./components/RiskReport.jsx";
import BackendBadge from "./components/BackendBadge.jsx";
import "./App.css";

const VIEWS = {
  INTAKE: "intake",
  AGENT: "agent",
  REPORT: "report",
};

export default function App() {
  const [view, setView] = useState(VIEWS.INTAKE);
  const [intakeResult, setIntakeResult] = useState(null);
  const [agentResult, setAgentResult] = useState(null);
  const reportFileRef = useRef();

  const handleReportImport = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const parsed = JSON.parse(ev.target.result);
        if (parsed.intakeData && parsed.analysis) {
          setIntakeResult({ intakeData: parsed.intakeData, analysis: parsed.analysis });
          if (parsed.agentResult) setAgentResult(parsed.agentResult);
          setView(VIEWS.REPORT);
        }
      } catch { /* ignore */ }
    };
    reader.readAsText(file);
    e.target.value = "";
  };

  return (
    <div className="app-shell">
      <header className="app-header">
        <div className="header-left">
          <div className="logo-mark">
            <span className="logo-bracket">[</span>
            <span className="logo-text">AGRI</span>
            <span className="logo-bracket">]</span>
          </div>
          <div className="header-titles">
            <h1 className="app-title">AI Governance Risk Intelligence</h1>
            <p className="app-subtitle">2LoD Assessment Platform · Financial Services</p>
          </div>
        </div>
        <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
          <button className="btn-secondary" style={{ fontSize: 11, padding: "6px 12px" }}
            onClick={() => reportFileRef.current?.click()}>
            Load Report JSON
          </button>
          <input ref={reportFileRef} type="file" accept=".json" style={{ display: "none" }} onChange={handleReportImport} />
          <BackendBadge />
        </div>
      </header>

      <nav className="app-nav">
        <button
          className={`nav-tab ${view === VIEWS.INTAKE ? "active" : ""}`}
          onClick={() => setView(VIEWS.INTAKE)}
        >
          <span className="tab-num">01</span>
          <span className="tab-label">Model Intake</span>
        </button>
        <div className="nav-connector" />
        <button
          className={`nav-tab ${view === VIEWS.AGENT ? "active" : ""}`}
          onClick={() => setView(VIEWS.AGENT)}
        >
          <span className="tab-num">02</span>
          <span className="tab-label">Agentic Review</span>
        </button>
        <div className="nav-connector" />
        <button
          className={`nav-tab ${view === VIEWS.REPORT ? "active" : ""} ${!intakeResult ? "disabled" : ""}`}
          onClick={() => intakeResult && setView(VIEWS.REPORT)}
        >
          <span className="tab-num">03</span>
          <span className="tab-label">Risk Report</span>
        </button>
      </nav>

      <main className="app-main">
        {view === VIEWS.INTAKE && (
          <IntakeForm
            onComplete={(result) => {
              setIntakeResult(result);
              setView(VIEWS.REPORT);
            }}
          />
        )}
        {view === VIEWS.AGENT && (
          <AgentReviewer
            onComplete={(result) => setAgentResult(result)}
            agentResult={agentResult}
          />
        )}
        {view === VIEWS.REPORT && (
          <RiskReport intakeResult={intakeResult} agentResult={agentResult} />
        )}
      </main>
    </div>
  );
}
