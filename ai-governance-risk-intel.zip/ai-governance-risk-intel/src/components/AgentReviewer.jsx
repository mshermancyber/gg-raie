import { useState } from "react";
import { chatCompletion } from "../lib/aiClient.js";
import { SYSTEM_PROMPT, buildAgentReasoningPrompt } from "../lib/prompts.js";

const ARTIFACT_TYPES = [
  "Model Card",
  "Architecture Notes",
  "Control Evidence",
  "Incident Summary",
  "Policy Text",
  "Validation Report Excerpt",
  "Vendor Due Diligence Document",
];

const MOCK_ARTIFACT = {
  type: "Model Card",
  text: `MODEL CARD — Digital Lending Decisioning Model v2.3
Prepared by: Model Development Team
Last Updated: Q4 2024

PURPOSE
Binary classification model for automated credit approval. Outputs: APPROVE / DECLINE / MANUAL_REVIEW.
Target population: Consumer loan applicants, $5K–$50K.

ARCHITECTURE
Algorithm: XGBoost (gradient boosting)
Features: 47 input variables including FICO, DTI, employment history, rent payment history (third-party), and three new alternative data signals added Q4 2024 (utility payment history, subscription service tenure, device usage patterns).

TRAINING DATA
Training period: 2018–2023 loan performance data (internal).
Third-party data: Vendor ABC alternative data feed. Integration live since Q3 2023.
Note: Vendor data dictionary reviewed by model team. No independent lineage assessment performed.

PERFORMANCE METRICS
Training AUC: 0.847
Out-of-sample AUC: 0.831
Disparate impact testing: Performed at initial build (Q1 2023). No subsequent fairness testing after Q4 2024 feature additions.

EXPLAINABILITY
SHAP values computed for internal monitoring. Not surfaced in adverse action notices (generic reason codes used per legal guidance).

DEPLOYMENT
Fully automated for scores >640 (APPROVE) and <560 (DECLINE).
Manual review queue: Scores 560–640.
No human review for automated approvals/declines.

MONITORING
PSI monitored monthly. Threshold for escalation: PSI > 0.25.
No concept drift or outcome monitoring defined.
Model redevelopment trigger: Not formally documented.

VALIDATION
Initial validation: Q2 2023. Passed.
Q4 2024 enhancement: Classified as minor by business line. Full revalidation not performed.
Next scheduled validation: Q2 2025 (pending resourcing).`
};

export default function AgentReviewer({ onComplete, agentResult }) {
  const [artifactType, setArtifactType] = useState("Model Card");
  const [artifactText, setArtifactText] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const loadMock = () => {
    setArtifactType(MOCK_ARTIFACT.type);
    setArtifactText(MOCK_ARTIFACT.text);
  };

  const handleAnalyze = async () => {
    setLoading(true);
    setError(null);
    try {
      const prompt = buildAgentReasoningPrompt(artifactText, artifactType);
      const raw = await chatCompletion(
        [{ role: "system", content: SYSTEM_PROMPT }, { role: "user", content: prompt }],
        { temperature: 0.2, max_tokens: 3000 }
      );
      const cleaned = raw.replace(/```json|```/g, "").trim();
      const result = JSON.parse(cleaned);
      onComplete({ artifactType, artifactText, analysis: result });
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const r = agentResult?.analysis;

  return (
    <div>
      <div className="section-header">
        <h2 className="section-title">Agentic 2LoD Review</h2>
        <p className="section-desc">
          Paste any artifact — model card, architecture notes, control evidence, incident summary — and the AI risk analyst will reason through it, flag gaps, and produce a challenge memo.
        </p>
      </div>

      {!r ? (
        <div>
          <div className="card" style={{ marginBottom: 20 }}>
            <div style={{ display: "flex", gap: 12, alignItems: "flex-start", marginBottom: 20 }}>
              <div className="field-group" style={{ flex: "0 0 200px", marginBottom: 0 }}>
                <label className="field-label">Artifact Type</label>
                <select
                  className="field-select field-input"
                  value={artifactType}
                  onChange={e => setArtifactType(e.target.value)}
                >
                  {ARTIFACT_TYPES.map(t => <option key={t}>{t}</option>)}
                </select>
              </div>
              <div style={{ display: "flex", gap: 8, alignSelf: "flex-end" }}>
                <button className="btn-primary" style={{ fontSize: 12, padding: "8px 16px" }} onClick={loadMock}>
                  Load Mock Model Card
                </button>
              </div>
            </div>

            <div className="field-group" style={{ marginBottom: 0 }}>
              <label className="field-label">Paste Artifact Text</label>
              <textarea
                className="field-input"
                rows={18}
                value={artifactText}
                onChange={e => setArtifactText(e.target.value)}
                placeholder="Paste model card, architecture document, control evidence, incident report, or policy text here..."
                style={{ fontFamily: "var(--font-mono)", fontSize: 12 }}
              />
            </div>
          </div>

          {error && <div className="error-state" style={{ marginBottom: 20 }}>{error}</div>}

          {loading ? (
            <div className="loading-state">
              <div className="spinner" />
              <span style={{ fontFamily: "var(--font-mono)", fontSize: 12 }}>
                Agent reasoning through artifact... building evidence trace...
              </span>
            </div>
          ) : (
            <button
              className="btn-primary"
              onClick={handleAnalyze}
              disabled={!artifactText.trim()}
            >
              Run Agentic Review →
            </button>
          )}
        </div>
      ) : (
        <AgentResults result={r} artifactType={agentResult.artifactType} onReset={() => onComplete(null)} />
      )}
    </div>
  );
}

function AgentResults({ result, artifactType, onReset }) {
  const severityColor = {
    LOW: "#22c55e", MEDIUM: "var(--warn)", HIGH: "var(--danger)", CRITICAL: "#dc2626"
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      {/* Header */}
      <div className="card" style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div>
          <div style={{ fontSize: 11, fontFamily: "var(--font-mono)", color: "var(--text-muted)", textTransform: "uppercase", marginBottom: 6 }}>
            {artifactType} · Agentic Review Complete
          </div>
          <div style={{ fontSize: 14, color: "var(--text-secondary)" }}>{result.artifactSummary}</div>
        </div>
        <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 8 }}>
          <div className={`risk-badge risk-${result.overallRiskSignal}`}>{result.overallRiskSignal}</div>
          <button className="btn-secondary" style={{ fontSize: 11, padding: "6px 12px" }} onClick={onReset}>
            New Review
          </button>
        </div>
      </div>

      {/* Reasoning Trace */}
      <div className="card">
        <div style={{ fontFamily: "var(--font-mono)", fontSize: 10, color: "var(--accent)", textTransform: "uppercase", letterSpacing: "1px", marginBottom: 16 }}>
          Reasoning Trace
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          {result.reasoningTrace?.map((step, i) => (
            <div key={i} style={{
              display: "flex", gap: 14,
              padding: "12px 14px",
              background: "var(--bg)",
              border: `1px solid ${step.concern ? "rgba(239,68,68,0.2)" : "var(--border)"}`,
              borderRadius: "var(--radius)",
            }}>
              <div style={{
                fontFamily: "var(--font-mono)", fontSize: 10,
                color: "var(--accent)", minWidth: 24,
                marginTop: 2,
              }}>
                {String(step.step).padStart(2, "0")}
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, color: "var(--text-primary)", marginBottom: 4 }}>{step.observation}</div>
                <div style={{ fontSize: 12, color: "var(--text-secondary)", marginBottom: step.concern ? 6 : 0 }}>{step.inference}</div>
                {step.concern && (
                  <div style={{
                    fontSize: 11, color: "var(--danger)",
                    fontFamily: "var(--font-mono)",
                    background: "var(--danger-dim)",
                    padding: "4px 8px", borderRadius: 4,
                  }}>
                    ⚑ {step.concern}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Evidence Present / Missing */}
      <div className="grid-2">
        <div className="card">
          <div style={{ fontFamily: "var(--font-mono)", fontSize: 10, color: "#22c55e", textTransform: "uppercase", letterSpacing: "1px", marginBottom: 14 }}>
            Evidence Present
          </div>
          {result.evidencePresent?.map((e, i) => (
            <div key={i} style={{ display: "flex", gap: 8, marginBottom: 8, fontSize: 13, color: "var(--text-secondary)" }}>
              <span style={{ color: "#22c55e", marginTop: 2 }}>✓</span> {e}
            </div>
          ))}
        </div>
        <div className="card">
          <div style={{ fontFamily: "var(--font-mono)", fontSize: 10, color: "var(--danger)", textTransform: "uppercase", letterSpacing: "1px", marginBottom: 14 }}>
            Evidence Missing
          </div>
          {result.evidenceMissing?.map((e, i) => (
            <div key={i} style={{ display: "flex", gap: 8, marginBottom: 8, fontSize: 13, color: "var(--text-secondary)" }}>
              <span style={{ color: "var(--danger)", marginTop: 2 }}>✗</span> {e}
            </div>
          ))}
        </div>
      </div>

      {/* Control Concerns */}
      <div className="card">
        <div style={{ fontFamily: "var(--font-mono)", fontSize: 10, color: "var(--accent)", textTransform: "uppercase", letterSpacing: "1px", marginBottom: 16 }}>
          Control Concerns
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {result.controlConcerns?.map((c, i) => (
            <div key={i} style={{
              padding: "12px 14px",
              background: "var(--bg)",
              border: "1px solid var(--border)",
              borderRadius: "var(--radius)",
              display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 12,
            }}>
              <div>
                <div style={{ fontSize: 12, fontFamily: "var(--font-mono)", color: "var(--text-muted)", marginBottom: 4 }}>
                  {c.control}
                  {c.regulatoryRef && <span style={{ color: "var(--accent)", marginLeft: 8 }}>· {c.regulatoryRef}</span>}
                </div>
                <div style={{ fontSize: 13, color: "var(--text-primary)" }}>{c.concern}</div>
              </div>
              <span style={{
                fontFamily: "var(--font-mono)", fontSize: 10, fontWeight: 700,
                color: severityColor[c.severity] || "var(--text-muted)",
                whiteSpace: "nowrap",
              }}>
                {c.severity}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Analyst Narrative */}
      <div className="card">
        <div style={{ fontFamily: "var(--font-mono)", fontSize: 10, color: "var(--accent)", textTransform: "uppercase", letterSpacing: "1px", marginBottom: 14 }}>
          Analyst Narrative
        </div>
        <div style={{ fontSize: 13, color: "var(--text-secondary)", lineHeight: 1.8, whiteSpace: "pre-line" }}>
          {result.analystNarrative}
        </div>
      </div>

      {/* Follow-up Actions */}
      {result.followUpActions?.length > 0 && (
        <div className="card">
          <div style={{ fontFamily: "var(--font-mono)", fontSize: 10, color: "var(--accent)", textTransform: "uppercase", letterSpacing: "1px", marginBottom: 14 }}>
            Follow-up Actions
          </div>
          {result.followUpActions.map((a, i) => (
            <div key={i} style={{ display: "flex", gap: 10, marginBottom: 8, fontSize: 13, color: "var(--text-secondary)" }}>
              <span style={{ fontFamily: "var(--font-mono)", color: "var(--accent)", fontSize: 11 }}>{i + 1}.</span> {a}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
