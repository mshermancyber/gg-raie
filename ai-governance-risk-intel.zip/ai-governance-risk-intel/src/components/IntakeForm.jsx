import { useState, useRef } from "react";
import { chatCompletion } from "../lib/aiClient.js";
import { SYSTEM_PROMPT, buildIntakeAnalysisPrompt } from "../lib/prompts.js";
import MOCK_SCENARIOS from "../lib/mockScenarios.json";

const FIELDS = [
  { section: "Model Identity", fields: [
    { key: "modelName", label: "Model Name / Version", type: "input" },
    { key: "purpose", label: "Model Purpose & Decision Type", type: "textarea", rows: 3 },
    { key: "businessLine", label: "Business Line", type: "input" },
    { key: "modelType", label: "Model Type / Algorithm", type: "input" },
    { key: "decisionImpact", label: "Decision Impact & Consumer Implications", type: "textarea", rows: 2 },
  ]},
  { section: "Data Governance", fields: [
    { key: "trainingDataSources", label: "Training Data Sources", type: "textarea", rows: 2 },
    { key: "piiPresent", label: "PII / PFI Present", type: "input" },
    { key: "dataLineageDocumented", label: "Data Lineage Documentation Status", type: "input" },
    { key: "dataQualityControls", label: "Data Quality Controls", type: "textarea", rows: 2 },
  ]},
  { section: "Explainability & Oversight", fields: [
    { key: "explainabilityMethod", label: "Explainability Method", type: "textarea", rows: 2 },
    { key: "humanReview", label: "Human Review Checkpoints", type: "textarea", rows: 2 },
    { key: "biasTestingPerformed", label: "Bias & Fairness Testing", type: "textarea", rows: 2 },
    { key: "driftMonitoring", label: "Drift & Performance Monitoring", type: "textarea", rows: 2 },
  ]},
  { section: "Regulatory & Validation", fields: [
    { key: "regulatoryFrameworks", label: "Regulatory Frameworks Referenced", type: "textarea", rows: 2 },
    { key: "validationStatus", label: "Model Validation Status", type: "textarea", rows: 2 },
    { key: "incidentResponse", label: "AI Incident Response Plan", type: "input" },
    { key: "additionalContext", label: "Additional Context / Evidence", type: "textarea", rows: 4 },
  ]},
];

const EMPTY = Object.fromEntries(FIELDS.flatMap(s => s.fields.map(f => [f.key, ""])));

export default function IntakeForm({ onComplete }) {
  const [formData, setFormData] = useState(EMPTY);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [showMockPicker, setShowMockPicker] = useState(false);
  const fileRef = useRef();

  const handleChange = (key, val) => setFormData(p => ({ ...p, [key]: val }));

  // ── JSON import ──────────────────────────────────────────────────────────
  const handleFileImport = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const parsed = JSON.parse(ev.target.result);
        // support both raw intakeData object and wrapped { intakeData: {...} }
        const data = parsed.intakeData || parsed;
        setFormData({ ...EMPTY, ...data });
        setError(null);
      } catch {
        setError("Invalid JSON file — expected intake data object.");
      }
    };
    reader.readAsText(file);
    e.target.value = "";
  };

  // ── JSON export ──────────────────────────────────────────────────────────
  const handleExportJson = () => {
    const blob = new Blob([JSON.stringify({ intakeData: formData }, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `intake_${(formData.modelName || "draft").replace(/\s+/g, "-")}.json`;
    a.click();
  };

  // ── Load mock scenario ───────────────────────────────────────────────────
  const loadMock = (scenario) => {
    setFormData({ ...EMPTY, ...scenario.intakeData });
    setShowMockPicker(false);
    setError(null);
  };

  // ── Submit ───────────────────────────────────────────────────────────────
  const handleSubmit = async () => {
    setLoading(true);
    setError(null);
    try {
      const prompt = buildIntakeAnalysisPrompt(formData);
      const raw = await chatCompletion(
        [{ role: "system", content: SYSTEM_PROMPT }, { role: "user", content: prompt }],
        { temperature: 0.2, max_tokens: 3000 }
      );
      const cleaned = raw.replace(/```json|```/g, "").trim();
      const result = JSON.parse(cleaned);
      onComplete({ intakeData: formData, analysis: result });
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const isComplete = formData.modelName && formData.purpose && formData.businessLine;

  return (
    <div>
      <div className="section-header">
        <h2 className="section-title">AI/ML System Intake Assessment</h2>
        <p className="section-desc">
          Complete the intake form, import a saved JSON, or load one of the 10 mock scenarios to run a demonstration assessment.
        </p>
      </div>

      {/* Toolbar */}
      <div style={{ display: "flex", gap: 10, marginBottom: 28, flexWrap: "wrap" }}>
        <button className="btn-primary" style={{ fontSize: 12, padding: "8px 16px" }}
          onClick={() => setShowMockPicker(p => !p)}>
          {showMockPicker ? "▲ Hide Scenarios" : "▼ Load Mock Scenario"}
        </button>
        <button className="btn-secondary" style={{ fontSize: 12, padding: "8px 16px" }}
          onClick={() => fileRef.current?.click()}>
          Import JSON
        </button>
        <input ref={fileRef} type="file" accept=".json" style={{ display: "none" }} onChange={handleFileImport} />
        {formData.modelName && (
          <button className="btn-secondary" style={{ fontSize: 12, padding: "8px 16px" }}
            onClick={handleExportJson}>
            Export JSON
          </button>
        )}
        <button className="btn-secondary" style={{ fontSize: 12, padding: "8px 16px" }}
          onClick={() => setFormData(EMPTY)}>
          Clear
        </button>
      </div>

      {/* Mock scenario picker */}
      {showMockPicker && (
        <div className="card" style={{ marginBottom: 24 }}>
          <div style={{ fontFamily: "var(--font-mono)", fontSize: 10, color: "var(--accent)", textTransform: "uppercase", letterSpacing: "1px", marginBottom: 14 }}>
            10 Mock Scenarios — click to load
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {MOCK_SCENARIOS.map(s => {
              const tier = s.label.match(/— (\w+)$/)?.[1] || "";
              return (
                <button key={s.id} onClick={() => loadMock(s)} style={{
                  display: "flex", alignItems: "center", justifyContent: "space-between",
                  padding: "10px 14px",
                  background: "var(--bg)",
                  border: "1px solid var(--border)",
                  borderRadius: "var(--radius)",
                  cursor: "pointer",
                  transition: "border-color 0.15s",
                  textAlign: "left",
                }}
                onMouseEnter={e => e.currentTarget.style.borderColor = "var(--accent)"}
                onMouseLeave={e => e.currentTarget.style.borderColor = "var(--border)"}
                >
                  <div>
                    <span style={{ fontFamily: "var(--font-mono)", fontSize: 10, color: "var(--text-muted)", marginRight: 10 }}>
                      {s.id.replace("mock-", "#")}
                    </span>
                    <span style={{ fontSize: 13, color: "var(--text-primary)" }}>
                      {s.label.replace(/ — \w+$/, "")}
                    </span>
                  </div>
                  <span className={`risk-badge risk-${tier}`}>{tier}</span>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Form */}
      {FIELDS.map(section => (
        <div key={section.section} className="card" style={{ marginBottom: 20 }}>
          <div style={{ fontFamily: "var(--font-mono)", fontSize: 10, color: "var(--accent)", textTransform: "uppercase", letterSpacing: "1px", marginBottom: 20 }}>
            {section.section}
          </div>
          {section.fields.map(field => (
            <div key={field.key} className="field-group">
              <label className="field-label">{field.label}</label>
              {field.type === "textarea" ? (
                <textarea className="field-input" rows={field.rows || 2}
                  value={formData[field.key] || ""}
                  onChange={e => handleChange(field.key, e.target.value)} />
              ) : (
                <input className="field-input" type="text"
                  value={formData[field.key] || ""}
                  onChange={e => handleChange(field.key, e.target.value)} />
              )}
            </div>
          ))}
        </div>
      ))}

      {error && <div className="error-state" style={{ marginBottom: 20 }}>{error}</div>}

      {loading ? (
        <div className="loading-state">
          <div className="spinner" />
          <span style={{ fontFamily: "var(--font-mono)", fontSize: 12 }}>
            Analyzing against SR 11-7, ECOA, NIST AI RMF...
          </span>
        </div>
      ) : (
        <button className="btn-primary" onClick={handleSubmit} disabled={!isComplete}>
          Run Governance Assessment →
        </button>
      )}
    </div>
  );
}
