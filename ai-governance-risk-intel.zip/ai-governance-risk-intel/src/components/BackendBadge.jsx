import { getActiveBackend } from "../lib/aiClient.js";

export default function BackendBadge() {
  const { backend, model } = getActiveBackend();
  const isLocal = backend === "local";

  return (
    <div style={{
      display: "flex",
      alignItems: "center",
      gap: "8px",
      padding: "6px 12px",
      background: "var(--bg-card)",
      border: "1px solid var(--border)",
      borderRadius: "var(--radius)",
    }}>
      <div style={{
        width: 7,
        height: 7,
        borderRadius: "50%",
        background: isLocal ? "var(--accent)" : "var(--warn)",
        boxShadow: isLocal
          ? "0 0 6px var(--accent-glow)"
          : "0 0 6px rgba(245,158,11,0.4)",
      }} />
      <span style={{
        fontFamily: "var(--font-mono)",
        fontSize: 10,
        color: "var(--text-muted)",
        textTransform: "uppercase",
        letterSpacing: "0.5px",
      }}>
        {isLocal ? "Local" : "API"}
      </span>
      <span style={{
        fontFamily: "var(--font-mono)",
        fontSize: 10,
        color: "var(--text-secondary)",
        maxWidth: 160,
        overflow: "hidden",
        textOverflow: "ellipsis",
        whiteSpace: "nowrap",
      }}>
        {model}
      </span>
    </div>
  );
}
