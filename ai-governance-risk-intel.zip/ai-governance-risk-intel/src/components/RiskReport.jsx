import { useState } from "react";
import { exportPdf } from "../lib/exportPdf.js";

const DIM_LABELS = {
  dataGovernance: "Data Governance",
  modelExplainability: "Model Explainability",
  biasAndFairness: "Bias & Fairness",
  humanOversight: "Human Oversight",
  regulatoryAlignment: "Regulatory Alignment",
  incidentAndDrift: "Incident & Drift Monitoring",
};

const RISK_ORDER = ["LOW", "ELEVATED", "HIGH", "UNACCEPTABLE"];
const riskScore = r => RISK_ORDER.indexOf(r);

export default function RiskReport({ intakeResult, agentResult }) {
  if (!intakeResult) {
    return (
      <div className="card" style={{ textAlign: "center", padding: "60px 40px" }}>
        <div style={{ fontFamily: "var(--font-mono)", color: "var(--text-muted)", fontSize: 13, marginBottom: 12 }}>
          No assessment data yet
        </div>
        <div style={{ color: "var(--text-muted)", fontSize: 13 }}>
          Complete the Model Intake tab to generate a risk report.
        </div>
      </div>
    );
  }

  const { intakeData, analysis } = intakeResult;
  const dims = analysis.dimensions;

  const handleExportPdf = () => exportPdf(intakeData, analysis, agentResult);

  const handleExportJson = () => {
    const payload = { intakeData, analysis, agentResult: agentResult || null, exportedAt: new Date().toISOString() };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `AI-Gov-Risk_${(intakeData.modelName || "report").replace(/\s+/g, "-")}_${new Date().toISOString().split("T")[0]}.json`;
    a.click();
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      {/* Summary header */}
      <div className="card" style={{
        background: analysis.riskTier === "UNACCEPTABLE" ? "rgba(220,38,38,0.05)"
          : analysis.riskTier === "HIGH" ? "rgba(239,68,68,0.05)" : "var(--bg-card)",
        borderColor: analysis.riskTier === "UNACCEPTABLE" ? "rgba(220,38,38,0.3)"
          : analysis.riskTier === "HIGH" ? "rgba(239,68,68,0.2)" : "var(--border)",
      }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 20 }}>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 11, fontFamily: "var(--font-mono)", color: "var(--text-muted)", textTransform: "uppercase", marginBottom: 8 }}>
              2LoD Governance Assessment · {new Date().toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" })}
            </div>
            <h2 style={{ fontSize: 22, fontWeight: 600, color: "var(--text-primary)", letterSpacing: "-0.5px", marginBottom: 10 }}>
              {intakeData.modelName}
            </h2>
            <div style={{ fontSize: 12, color: "var(--text-muted)", fontFamily: "var(--font-mono)", marginBottom: 16 }}>
              {intakeData.businessLine}
            </div>
            <p style={{ fontSize: 13, color: "var(--text-secondary)", lineHeight: 1.7, maxWidth: 700 }}>
              {analysis.riskSummary}
            </p>
          </div>
          <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 12, flexShrink: 0 }}>
            <div style={{ textAlign: "right" }}>
              <div style={{ fontSize: 10, fontFamily: "var(--font-mono)", color: "var(--text-muted)", textTransform: "uppercase", marginBottom: 6 }}>
                Overall Risk Tier
              </div>
              <div className={`risk-badge risk-${analysis.riskTier}`} style={{ fontSize: 14, padding: "6px 14px" }}>
                {analysis.riskTier}
              </div>
            </div>
            {analysis.escalationRequired && (
              <div style={{
                padding: "8px 12px",
                background: "var(--danger-dim)",
                border: "1px solid var(--danger)",
                borderRadius: "var(--radius)",
                fontSize: 11,
                fontFamily: "var(--font-mono)",
                color: "var(--danger)",
                textAlign: "center",
              }}>
                ⚑ ESCALATION REQUIRED
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Dimension grid */}
      <div>
        <div style={{ fontSize: 11, fontFamily: "var(--font-mono)", color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 14 }}>
          Risk Dimensions
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 12 }}>
          {Object.entries(dims).map(([key, dim]) => (
            <DimCard key={key} label={DIM_LABELS[key] || key} dim={dim} />
          ))}
        </div>
      </div>

      {/* Challenge Questions */}
      <div className="card">
        <div style={{ fontFamily: "var(--font-mono)", fontSize: 10, color: "var(--accent)", textTransform: "uppercase", letterSpacing: "1px", marginBottom: 16 }}>
          2LoD Challenge Questions
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {analysis.challengeQuestions?.map((q, i) => (
            <div key={i} style={{
              display: "flex", gap: 12,
              padding: "10px 14px",
              background: "var(--bg)",
              border: "1px solid var(--border)",
              borderRadius: "var(--radius)",
            }}>
              <span style={{ fontFamily: "var(--font-mono)", color: "var(--accent)", fontSize: 11, minWidth: 20, marginTop: 1 }}>
                Q{i + 1}
              </span>
              <span style={{ fontSize: 13, color: "var(--text-primary)", lineHeight: 1.6 }}>{q}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Recommended Actions */}
      <div className="card">
        <div style={{ fontFamily: "var(--font-mono)", fontSize: 10, color: "var(--accent)", textTransform: "uppercase", letterSpacing: "1px", marginBottom: 16 }}>
          Recommended Actions
        </div>
        {analysis.recommendedActions?.map((a, i) => (
          <div key={i} style={{ display: "flex", gap: 10, marginBottom: 10, fontSize: 13, color: "var(--text-secondary)", lineHeight: 1.6 }}>
            <span style={{ fontFamily: "var(--font-mono)", color: "var(--accent)", fontSize: 11, minWidth: 20, marginTop: 2 }}>{i + 1}.</span>
            {a}
          </div>
        ))}
      </div>

      {/* Escalation Rationale */}
      {analysis.escalationRationale && (
        <div className="card" style={{
          borderColor: analysis.escalationRequired ? "rgba(239,68,68,0.3)" : "var(--border)",
          background: analysis.escalationRequired ? "rgba(239,68,68,0.04)" : "var(--bg-card)",
        }}>
          <div style={{ fontFamily: "var(--font-mono)", fontSize: 10, color: analysis.escalationRequired ? "var(--danger)" : "var(--text-muted)", textTransform: "uppercase", letterSpacing: "1px", marginBottom: 10 }}>
            Escalation Rationale
          </div>
          <div style={{ fontSize: 13, color: "var(--text-secondary)", lineHeight: 1.7 }}>
            {analysis.escalationRationale}
          </div>
        </div>
      )}

      {/* Agent Review crosslink */}
      {agentResult && (
        <div className="card" style={{ borderColor: "var(--accent)", background: "var(--accent-dim)" }}>
          <div style={{ fontFamily: "var(--font-mono)", fontSize: 10, color: "var(--accent)", textTransform: "uppercase", letterSpacing: "1px", marginBottom: 10 }}>
            Agentic Review Crossref · {agentResult.artifactType}
          </div>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <div style={{ fontSize: 13, color: "var(--text-secondary)" }}>
              {agentResult.analysis.artifactSummary}
            </div>
            <div className={`risk-badge risk-${agentResult.analysis.overallRiskSignal}`} style={{ marginLeft: 16, flexShrink: 0 }}>
              {agentResult.analysis.overallRiskSignal}
            </div>
          </div>
          {agentResult.analysis.controlConcerns?.length > 0 && (
            <div style={{ marginTop: 10, fontSize: 12, color: "var(--text-muted)" }}>
              {agentResult.analysis.controlConcerns.length} control concern(s) identified in artifact review
            </div>
          )}
        </div>
      )}

      {/* Export */}
      <div style={{ display: "flex", gap: 10, paddingTop: 8 }}>
        <button className="btn-primary" onClick={handleExportPdf}>
          Export PDF Report →
        </button>
        <button className="btn-secondary" onClick={handleExportJson}>
          Export JSON
        </button>
      </div>
    </div>
  );
}

function DimCard({ label, dim }) {
  const [expanded, setExpanded] = useState(false);
  const hasContent = (dim.findings?.length + dim.gaps?.length) > 0;

  return (
    <div
      className="card"
      onClick={() => hasContent && setExpanded(e => !e)}
      style={{
        cursor: hasContent ? "pointer" : "default",
        transition: "border-color 0.2s",
      }}
    >
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
        <div style={{ fontSize: 11, fontFamily: "var(--font-mono)", color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: "0.5px", lineHeight: 1.4 }}>
          {label}
        </div>
        <div className={`risk-badge risk-${dim.rating}`}>{dim.rating}</div>
      </div>

      {expanded && (
        <div style={{ marginTop: 12 }}>
          {dim.findings?.length > 0 && (
            <div style={{ marginBottom: 10 }}>
              <div style={{ fontSize: 10, fontFamily: "var(--font-mono)", color: "#22c55e", textTransform: "uppercase", marginBottom: 6 }}>Findings</div>
              {dim.findings.map((f, i) => (
                <div key={i} style={{ fontSize: 12, color: "var(--text-secondary)", marginBottom: 4, paddingLeft: 10, borderLeft: "2px solid #22c55e" }}>{f}</div>
              ))}
            </div>
          )}
          {dim.gaps?.length > 0 && (
            <div style={{ marginBottom: 10 }}>
              <div style={{ fontSize: 10, fontFamily: "var(--font-mono)", color: "var(--danger)", textTransform: "uppercase", marginBottom: 6 }}>Gaps</div>
              {dim.gaps.map((g, i) => (
                <div key={i} style={{ fontSize: 12, color: "var(--text-secondary)", marginBottom: 4, paddingLeft: 10, borderLeft: "2px solid var(--danger)" }}>{g}</div>
              ))}
            </div>
          )}
          {dim.regulatoryRefs?.length > 0 && (
            <div>
              <div style={{ fontSize: 10, fontFamily: "var(--font-mono)", color: "var(--accent)", textTransform: "uppercase", marginBottom: 6 }}>Regulatory Refs</div>
              {dim.regulatoryRefs.map((r, i) => (
                <div key={i} style={{ fontSize: 11, color: "var(--accent)", fontFamily: "var(--font-mono)" }}>{r}</div>
              ))}
            </div>
          )}
        </div>
      )}

      {hasContent && !expanded && (
        <div style={{ fontSize: 10, color: "var(--text-muted)", fontFamily: "var(--font-mono)" }}>
          {dim.findings?.length || 0} finding(s) · {dim.gaps?.length || 0} gap(s) · click to expand
        </div>
      )}
    </div>
  );
}


